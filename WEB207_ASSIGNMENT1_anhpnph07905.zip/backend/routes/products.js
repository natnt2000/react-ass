const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

router.get('/', async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (error) {
        res.json({message: error});
    }
    // res.send('Haha product');
});

router.post('/', async (req, res) => {
    const product = new Product({
        name: req.body.name,
        image: req.body.image,
        price: req.body.price
    });
    try {
        const saveProduct = await product.save();
        res.json(saveProduct);
    } catch (error) {
        res.json({message: error});
    }
    // console.log(req.body);
});

router.put('/:_id', async (req, res) => {
    try {
        const updateProduct = await Product.updateOne(
            { _id: req.params._id }, 
            { $set: 
                {
                    name: req.body.name,
                    image: req.body.image,
                    price: req.body.price,
                } 
            });
        res.json(updateProduct);
    } catch (error) {
        res.json({message: error});
    }
});

router.delete('/:_id', async (req, res) => {
    try {
        const removeProduct = await Product.deleteOne({ _id: req.params._id });
        res.json(removeProduct);
    } catch (error) {
        res.json({message: error});
    }
});

module.exports = router;