import React, { useState, useEffect } from 'react';
import Routers from './routers'
import productApi from './product-api';
import productApiRequest from './api/productApi';

const App = () => {

  const [products, setProducts] = useState([]);

  useEffect(() => {
    getProducts();
  }, []);

  const getProducts = async () => {
    const { data } = await productApiRequest.getAll();
    setProducts(data);
    console.log(data);
  }
  
  const onHandleRemove = async (_id) => {
    const newProducts = products.filter(product => product._id !== _id);
    setProducts(newProducts);
    const { data } = await productApiRequest.remove(_id);
    console.log(data);
  }

  const onHandleAdd = async (product) => {
    const { data } = await productApiRequest.create(product);
    setProducts([
      ...products,
      data
    ]);
    console.log(data); 
  }

  const onHandleUpdate = async (_id, product) => {
    const newProducts = products.map(pro => (pro._id == _id ? {...product} : pro));
    setProducts(newProducts);
    const { data } = await productApiRequest.update(_id, product);
    console.log(data);
  }

  return (
    <div className="App">
      <Routers 
        products={products} 
        onRemove={onHandleRemove} 
        onAdd={onHandleAdd}
        onUpdate={onHandleUpdate}
      />
    </div>
  )

}
export default App;