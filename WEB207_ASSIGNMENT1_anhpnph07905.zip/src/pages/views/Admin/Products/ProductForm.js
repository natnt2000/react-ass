import React, { useState } from 'react'
import PropTypes from 'prop-types'
import { useForm } from 'react-hook-form';
import { Link, useParams, useHistory } from 'react-router-dom';
import { storage } from '../../../../firebase'


const ProductForm = ({ onAdd, title, products, onUpdate }) => {
    const { _id } = useParams();

    const product = _id ? products.find(product => product._id == _id) : {};

    const { register, handleSubmit, watch, errors } = useForm();

    const [valueInput, setValueInput] = useState(product);

    // const [image, setImage] = useState(null);
    const onHandleChange = (e) => {
        const { name, value } = e.target;
        
        setValueInput({
            ...valueInput,
            [name]: value
        })
    }


    const history = useHistory();

    const onHandleSubmit = data => {
        // console.log(data.image[0]);
        if(data.image[0]){
            const image = data.image[0];
            const uploadTask = storage.ref(`images/products/${image.name}`).put(image);
            uploadTask.on(
                "state_changed",
                snapshot => {},
                error => {
                  console.log(error);
                },
                () => {
                    storage
                    .ref("images/products")
                    .child(image.name)
                    .getDownloadURL()
                    .then(url => {
                        if(!_id){
                            onAdd({
                                ...valueInput,
                                image: url
                            });
                        }else{
                            onUpdate(_id, {
                                ...valueInput,
                                image: url
                            });
                        }
                    });
                }
            );
        }else{
            onUpdate(_id, valueInput);
        }

        history.push({
            pathname: "/admin/products", 
        });
    }

    return (
        <div>
            <h1 className="h3 mb-2 text-gray-800">{title}</h1>
            <div className="card shadow mb-4">
                <div className="card-body">
                    <div className="col-6">
                        <form onSubmit={handleSubmit(onHandleSubmit)}>
                            <div className="form-group">
                                <label>Name</label>
                                <input 
                                    type="text" 
                                    className="form-control"
                                    name="name"
                                    defaultValue={valueInput.name || ""}
                                    message={errors}
                                    onChange={onHandleChange}
                                    ref={register({ required: true, minLength: 5, pattern: /([^\s])/})}
                                />
                                {errors.name && errors.name.type === 'required' && (
                                    <p style={{color: "red"}}>This field is required</p>
                                )}

                                {errors.name && errors.name.type === 'minLength' && (
                                    <p style={{color: "red"}}>This field is  required min length of 5</p>
                                )}
                                {errors.name && errors.name.type === 'pattern' && (
                                    <p style={{color: "red"}}>This field empty</p>
                                )}
                            </div>
                            <div className="form-group">

                                <label>Image</label>
                                { _id ? 
                                    (<div>
                                        <img className="img-thumbnail mb-3" style={{width: 200 + 'px'}} src={valueInput.image || ""}/>
                                    </div>)
                                    : ""  
                                }
                                <input 
                                    type="file" 
                                    className="form-control"
                                    name="image"
                                    // onChange={onHandleChangFile}
                                    ref={_id ? register({ pattern: /\.(gif|jpe?g|tiff|png|webp|bmp)$/i, max: 2000000 }) : register({ required: true, pattern: /\.(gif|jpe?g|tiff|png|webp|bmp)$/i, max: 2000000 })}
                                />
                                {errors.image && errors.image.type === 'required' && (
                                    <p style={{color: "red"}}>This is required</p>
                                )}
                                {errors.image && errors.image.type === 'pattern' && (
                                    <p style={{color: "red"}}>Image format is invalid</p>
                                )}
                            </div>
                            <div className="form-group">
                                <label>Price</label>
                                <input 
                                    type="number" 
                                    className="form-control"
                                    name="price"
                                    defaultValue={valueInput.price || ""}
                                    onChange={onHandleChange}
                                    ref={register({ required: true, min: 1 })}
                                />
                                {errors.price && errors.price.type === 'required' && (
                                    <p style={{color: "red"}}>This is required</p>
                                )}
                                {errors.price && errors.price.type === 'min' && (
                                    <p style={{color: "red"}}>This is field required min of 1</p>
                                )}
                            </div>
                            
                            <button type="submit" className="btn btn-primary">Submit</button>
                            <Link to="/admin/products" className="btn btn-info ml-2">Cancel</Link>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

ProductForm.propTypes = {

}

export default ProductForm
