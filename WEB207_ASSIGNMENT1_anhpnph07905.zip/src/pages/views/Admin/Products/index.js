import React from 'react'
import PropTypes from 'prop-types';
import { Link, useLocation } from 'react-router-dom';

const ProductsManager = ({ products, onRemove }) => {
    const removeHandle = (_id) => {
        onRemove(_id)
    }
    // const { message } = useLocation();
    return (
        <div>
            {/* Page Heading */}
            <h1 className="h3 mb-2 text-gray-800">Tables</h1>
            <p className="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more
          information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official
            DataTables documentation</a>.</p>
            {/* DataTales Example */}
            <div className="card shadow mb-4">
                <div className="card-header py-3">
                    <h6 className="m-0 font-weight-bold text-primary">DataTables Example</h6>
                </div>
                <div className="card-body">
                    <div className="table-responsive">
                        
                        {/* {message ? <div className="alert alert-success col-6" role="alert">{message}</div> : null} */}
                        <Link className="btn btn-primary float-right mb-3" to="/admin/products/add">Create new</Link>
                        <table className="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products.map(({ _id, name, image, price }, index) => (
                                    <tr key={index}>
                                        <th scope="row">{index+1}</th>
                                        <td>{name}</td>
                                        <td><img src={image} alt="" width="150" /></td>
                                        <td>{price}</td>
                                        <td>
                                            <div className="btn-group">
                                                <Link className="btn btn-info mr-2" to={`/admin/products/${_id}/edit`}>Edit</Link>
                                                <button className="btn btn-danger" onClick={() => removeHandle(_id)}>Remove</button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    )
}

ProductsManager.propTypes = {

}

export default ProductsManager
