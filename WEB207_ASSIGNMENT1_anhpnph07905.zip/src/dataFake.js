const dataFake = [
    {
        "id": "1",
        "name": "Awesome Steel Gloves",
        "image": "https://s3.amazonaws.com/uifaces/faces/twitter/hjartstrorn/128.jpg",
        "price": "93.00"
    },
    {
        "id": "2",
        "name": "Fantastic Frozen Fish",
        "image": "https://s3.amazonaws.com/uifaces/faces/twitter/dss49/128.jpg",
        "price": "641.00"
    },
    {
        "id": "3",
        "name": "Unbranded Frozen Chair",
        "image": "https://s3.amazonaws.com/uifaces/faces/twitter/_williamguerra/128.jpg",
        "price": "95.00"
    },
    {
        "id": "4",
        "name": "Gorgeous Fresh Table",
        "image": "https://s3.amazonaws.com/uifaces/faces/twitter/enjoythetau/128.jpg",
        "price": "821.00"
    },
    {
        "id": "5",
        "name": "Unbranded Frozen Salad",
        "image": "https://s3.amazonaws.com/uifaces/faces/twitter/jennyshen/128.jpg",
        "price": "675.00"
    },
    {
        "id": "6",
        "name": "Handmade Cotton Chicken",
        "image": "https://s3.amazonaws.com/uifaces/faces/twitter/felipeapiress/128.jpg",
        "price": "189.00"
    },
        {
        "id": "7",
        "name": "Intelligent Soft Shirt",
        "image": "https://s3.amazonaws.com/uifaces/faces/twitter/ariil/128.jpg",
        "price": "532.00"
    },
    {
        "id": "8",
        "name": "Generic Granite Keyboard",
        "image": "https://s3.amazonaws.com/uifaces/faces/twitter/scrapdnb/128.jpg",
        "price": "879.00"
    }
]
export default dataFake;