import React from 'react'
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import LayoutMain from '../pages/layouts/LayoutMain'
import LayoutAdmin from '../pages/layouts/LayoutAdmin'
//Admin
import Dashboard from '../pages/views/Admin/Dashboard'
import ProductsManager from '../pages/views/Admin/Products'
import ProductForm from '../pages/views/Admin/Products/ProductForm';


//Views
import About from '../pages/views/Main/About'
import Home from '../pages/views/Main/Home'
import ProductDetail from '../pages/views/Main/Product/ProductDetail';


const Routers = ({ products, onRemove, onAdd, onUpdate  }) => {
    const onHandleRemove = (_id) => {
        onRemove(_id)
    }
    const onHandleAdd = (product) => {
        onAdd(product);
    }
    const onHandleUpdate = (_id, product) => {
        onUpdate(_id, product);
    }
    return (
        <Router>
            <Switch>
                <Route path="/admin">
                    <LayoutAdmin>
                        <Switch>
                            <Route path='/admin' exact>
                                <Dashboard />
                            </Route>
                            <Route path='/admin/products' exact>
                                <ProductsManager products={products} onRemove={onHandleRemove} />
                            </Route>
                            <Route path='/admin/products/add'>
                                <ProductForm title="Add New Product" onAdd={onHandleAdd}/>
                            </Route>
                            <Route path='/admin/products/:_id/edit'>
                                <ProductForm title="Edit Product" products={products} onUpdate={onHandleUpdate}/>
                            </Route>
                        </Switch>
                    </LayoutAdmin>
                </Route>
                <Route path="/">
                    <LayoutMain>
                        <Switch>
                            <Route path="/" exact>
                                <Home products={products}/>
                            </Route>
                            <Route path="/products/:_id" >
                                <ProductDetail products={products}/>
                            </Route>
                        </Switch>
                    </LayoutMain>
                </Route>
            </Switch>
        </Router>

        
    )
}

Routers.propTypes = {

}

export default Routers
