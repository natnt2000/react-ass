import axios from 'axios';

export default axios.create({
    baseURL: `https://5f11609365dd950016fbd46a.mockapi.io`
})