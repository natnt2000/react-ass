import React from 'react'
import PropTypes from 'prop-types'

const About = props => {
    return (
        <div>
            About page
        </div>
    )
}

About.propTypes = {

}

export default About
